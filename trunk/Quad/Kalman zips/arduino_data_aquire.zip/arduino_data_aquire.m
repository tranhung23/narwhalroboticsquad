% Author :Sreeram Mohan
%   Tested with arduino Duemilanove 
%   Open source software for the arduino duemilanove !
%   Feel free to use and suggest updates !!!!
clear all;
s1 = serial('COM3');                            %define serial port
s1.BaudRate=9600;                               %define baud rate
     
%open serial port
fopen(s1);
clear data;
for i= 1:100                                 %acquisition of 100 points
    data=fscanf(s1);%read sensor
    sine_data=str2double(data);
    y = 5*sin(2*3.14*2000*sine_data);
    subplot(1,2,1)
    stem(y,i);
    title('Values at each time interval');
    xlabel('number of points');
    ylabel('Sine Values for each point');
    drawnow;

    subplot(1,2,2)
    hold on;
    plot(sine_data,y,'--rs','LineWidth',2,...
                           'MarkerEdgeColor','k',...
                           'MarkerFaceColor','g',...
                           'MarkerSize',10)
    title('Sine Wave plotted from data obtained from arduino');
    xlabel('number of points');
    ylabel('Sine values ');
    drawnow;
end
% close the serial port!
fclose(s1);  