/** @file
 *	@brief MAVLink comm protocol.
 *	@see http://pixhawk.ethz.ch/software/mavlink
 *	 Generated on Wednesday, May 18 2011, 03:15 UTC
 */
#ifndef MAVLINK_H
#define MAVLINK_H

#include "common.h"

#endif
