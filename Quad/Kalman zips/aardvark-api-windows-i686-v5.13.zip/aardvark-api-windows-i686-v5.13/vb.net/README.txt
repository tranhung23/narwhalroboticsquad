                  Total Phase Aardvark Sample Code
                  --------------------------------

Introduction
------------
This directory contains examples that use the Aardvark Visual Basic
.NET language bindings.


Contents
--------
See top level EXAMPLES.txt for descriptions of each example.


Instructions
------------
1) Copy 'aardvark.dll' to the WINDOWS/System32 folder

2) Open the "examples" solution in Visual Studio .NET 2005 or later

3) Build and run the project

4) Use the supplied GUI form to execute the examples
